//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// jacob3001_initialize.cpp
//
// Code generation for function 'jacob3001_initialize'
//

// Include files
#include "jacob3001_initialize.h"

// Function Definitions
void jacob3001_initialize()
{
}

// End of code generation (jacob3001_initialize.cpp)
