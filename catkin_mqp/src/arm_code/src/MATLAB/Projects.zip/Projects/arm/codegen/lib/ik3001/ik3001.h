//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ik3001.h
//
// Code generation for function 'ik3001'
//

#ifndef IK3001_H
#define IK3001_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void ik3001(const double endPos[3], double J[3]);

#endif
// End of code generation (ik3001.h)
