//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// jacob3001.h
//
// Code generation for function 'jacob3001'
//

#ifndef JACOB3001_H
#define JACOB3001_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void jacob3001(const double ja[3], double J[18]);

#endif
// End of code generation (jacob3001.h)
