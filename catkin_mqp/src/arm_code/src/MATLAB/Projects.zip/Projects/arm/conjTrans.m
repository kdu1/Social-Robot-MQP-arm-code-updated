function ct = conjTrans(A)
    ct = ctranspose(A);
end
