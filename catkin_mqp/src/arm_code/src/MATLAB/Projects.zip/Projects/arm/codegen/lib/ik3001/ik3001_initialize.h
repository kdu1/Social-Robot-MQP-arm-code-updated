//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ik3001_initialize.h
//
// Code generation for function 'ik3001_initialize'
//

#ifndef IK3001_INITIALIZE_H
#define IK3001_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void ik3001_initialize();

#endif
// End of code generation (ik3001_initialize.h)
