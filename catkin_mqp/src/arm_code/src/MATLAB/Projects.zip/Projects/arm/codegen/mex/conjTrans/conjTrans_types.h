//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// conjTrans_types.h
//
// Code generation for function 'conjTrans'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "emlrt.h"

// End of code generation (conjTrans_types.h)
